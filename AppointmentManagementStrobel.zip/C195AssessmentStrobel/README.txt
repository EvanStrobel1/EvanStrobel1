Appointment and Customer Data Tracker
Application for tracking Appointments and Customers, as well as all relevant data
Author: Evan Strobel
estrob2@wgu.edu
Apache NetBeans IDE 11.3
Student Application Version 1.1
3/18/2022
JDK 11.0.8
JavaFX 17
Run the program by opening the project in NetBeans and clicking on the Run Project button or pressing F6.
The additional report details the different locations present in the appointments and the amounts of each in the database.
mysql-connector-java-8.0.26